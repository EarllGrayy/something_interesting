-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: levchukdb
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `passenger`
--

DROP TABLE IF EXISTS `passenger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `passenger` (
  `Passport_id` varchar(255) NOT NULL,
  `Passenger_Surname` varchar(255) NOT NULL,
  `Passenger_Name` varchar(255) NOT NULL,
  `Name_by_father` varchar(255) DEFAULT NULL,
  `Date_of_birth` date NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `Phone_number` varchar(255) NOT NULL,
  PRIMARY KEY (`Passport_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passenger`
--

LOCK TABLES `passenger` WRITE;
/*!40000 ALTER TABLE `passenger` DISABLE KEYS */;
INSERT INTO `passenger` VALUES ('0980678412','Крестова','Анна','Викторовна','2003-04-02','Ж','+79985571203'),('1178689455','Макаренко','Даниил','Максимович','1991-11-09','М','+75165498067'),('1234567890','Иванов','Иван','Петрович','1990-01-15','М','+71234567890'),('2190876543','Иванов','Андрей','Александрович','1999-06-06','М','+79785129810'),('2345678901','Петрова','Мария','Ивановна','1985-03-25','Ж','+79876543210'),('3238657904','Ильиченко','Константин','Николаевич','1997-06-08','М','+79781438971'),('3456789012','Сидоров','Павел','Александрович','1992-07-14','М','+70123456789'),('4567890123','Кузнецова','Ольга','Дмитриевна','1988-11-30','Ж','+70987654321'),('4590873217','Косарева','Алина','Игоревна','1990-12-11','Ж','+74438901276'),('5678901234','Смирнов','Андрей','Николаевич','1995-05-18','М','+70098765432'),('6789012345','Попова','Елена','Сергеевна','1991-09-22','Ж','+70987654320'),('6789932117','Заричная','Ирина','Андреевна','2001-01-03','Ж','+79881201162');
/*!40000 ALTER TABLE `passenger` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-23 21:52:18
