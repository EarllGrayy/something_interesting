-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: levchukdb
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket` (
  `Ticket_id` int NOT NULL,
  `Passport_fk` varchar(255) NOT NULL,
  `Carriage_fk` int NOT NULL,
  `Flight_fk` int NOT NULL,
  `Place_number` int NOT NULL,
  `Ticket_price` int NOT NULL,
  `Extra_services` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Ticket_id`),
  KEY `idx_Flight_id` (`Flight_fk`),
  KEY `idx_carriage_fk` (`Carriage_fk`),
  KEY `FK_Passenger_Ticket` (`Passport_fk`),
  CONSTRAINT `FK_Passenger_Ticket` FOREIGN KEY (`Passport_fk`) REFERENCES `passenger` (`Passport_id`),
  CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`Carriage_fk`) REFERENCES `carriage` (`Carriage_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ticket_ibfk_3` FOREIGN KEY (`Flight_fk`) REFERENCES `flight` (`Flight_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` VALUES (123456,'2345678901',12345678,12345,10,6000,'Питание'),(234567,'4567890123',34567890,23456,5,15000,'Багаж'),(345678,'2190876543',34567890,23456,15,15000,'WiFi'),(456789,'5678901234',34567890,23456,3,15000,'Питание, багаж'),(567890,'4590873217',12345678,12345,8,6000,NULL),(569834,'6789932117',34899912,57609,11,20000,'Страховка, ужин'),(678901,'6789012345',34567890,23456,12,15000,'WiFi, питание'),(9345767,'1234567890',23456789,21878,1,10000,'Страховка'),(29098609,'1178689455',12345678,12345,54,6000,'Ужин'),(47789087,'0980678412',34899912,57609,5,20000,'Страховка'),(56790011,'3456789012',23456789,21878,16,10000,NULL),(68909832,'3238657904',23456789,21878,12,10000,'Провоз животных');
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-23 21:52:18
